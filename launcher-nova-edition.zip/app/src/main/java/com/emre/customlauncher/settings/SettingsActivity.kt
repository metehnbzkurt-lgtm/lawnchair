
package com.emre.customlauncher.settings

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.emre.customlauncher.PrefsStore

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Scaffold { padding ->
                    LazyColumn(Modifier.padding(padding).padding(16.dp)) {
                        item { Text("Custom Lawnchair - Nova Edition", style = MaterialTheme.typography.headlineSmall) }
                        item { Spacer(Modifier.height(16.dp)); SearchBarSection() }
                        item { FolderSection() }
                        item { HomeScreenSection() }
                        item { DrawerSection() }
                        item { AppearanceSection() }
                    }
                }
            }
        }
    }
}

@Composable
fun SearchBarSection() {
    val prefs by PrefsStore.searchBar.collectAsState()
    Card(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text("Uygulama menüsü arama çubuğu", style = MaterialTheme.typography.titleMedium)
            Text("Yerleştirme: ${prefs.position} | Şeffaflık: ${prefs.transparency}% | Köşe: ${prefs.cornerRadius}dp")
            Slider(value = prefs.transparency.toFloat(), onValueChange = { PrefsStore.searchBar.value = prefs.copy(transparency = it.toInt()) }, valueRange = 0f..100f)
            Text("Logo: ${prefs.logoType} - Tasarım: ${prefs.designEnabled} Gölge: ${prefs.shadowEnabled}")
        }
    }
}
@Composable
fun FolderSection() {
    val prefs by PrefsStore.folder.collectAsState()
    Card(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text("Klasörler", style = MaterialTheme.typography.titleMedium)
            Text("Simge: %${prefs.iconSize} | Stil: ${prefs.style} | Köşe: ${prefs.cornerRadius}dp | Kaydırma: ${prefs.scrollDirection}")
        }
    }
}
@Composable
fun HomeScreenSection() {
    val prefs by PrefsStore.home.collectAsState()
    Card(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text("Ana ekran", style = MaterialTheme.typography.titleMedium)
            Text("Kılavuz: ${prefs.gridSize.first}x${prefs.gridSize.second} | Widget köşe: ${prefs.widgetCornerRadius}dp | Duvar kağıdı kaydırma: ${prefs.wallpaperScrolling}")
        }
    }
}
@Composable
fun DrawerSection() {
    val prefs by PrefsStore.drawer.collectAsState()
    Card(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text("Uygulama menüsü", style = MaterialTheme.typography.titleMedium)
            Text("Kılavuz: ${prefs.gridSize.first}x${prefs.gridSize.second} | Stil: ${prefs.drawerStyle} | Akıllı Klasörler: ${prefs.smartFolders}")
        }
    }
}
@Composable
fun AppearanceSection() {
    val prefs by PrefsStore.appearance.collectAsState()
    Card(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text("Görünüm", style = MaterialTheme.typography.titleMedium)
            Text("Bildirim çubuğu: ${prefs.showStatusBar} Şeffaf: ${prefs.transparentStatusBar} | Geri alma: ${prefs.showUndoBar}")
        }
    }
}
