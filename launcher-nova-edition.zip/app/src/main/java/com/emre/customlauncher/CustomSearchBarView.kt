
package com.emre.customlauncher

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.widget.FrameLayout
import androidx.core.graphics.ColorUtils

// Senin istediğin arama çubuğunu birebir çizen view
class CustomSearchBarView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var prefs = PrefsStore.searchBar.value

    fun updatePrefs(newPrefs: SearchBarPrefs) {
        prefs = newPrefs
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        // Şeffaflık
        val alpha = (255 * (100 - prefs.transparency) / 100)
        paint.alpha = alpha
        
        // Köşe yarıçapı
        val radius = prefs.cornerRadius * resources.displayMetrics.density
        
        // Arka plan - Tasarım
        if (prefs.designEnabled) {
            paint.color = Color.parseColor("#1E1E1E")
            canvas.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), radius, radius, paint)
        }
        
        // Gölge
        if (prefs.shadowEnabled) {
            paint.setShadowLayer(8f, 0f, 4f, Color.BLACK)
        }
        
        super.onDraw(canvas)
    }
}
