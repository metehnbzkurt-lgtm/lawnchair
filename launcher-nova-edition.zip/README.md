
# Custom Lawnchair Launcher - Nova Özellikli

Bu proje Lawnchair 14 (Launcher3 tabanlı) üzerine senin paylaştığın tüm özelleştirmeleri eklemek için oluşturuldu.

## İçerdiği Özellikler (Ekran görüntülerinden çıkarıldı)

### 1. Uygulama Menüsü Arama Çubuğu
- Yerleştirme: Alt / Üst / Hiçbiri
- Şeffaflık: 0-100% slider
- Tasarım + Gölge toggle
- Köşe Yarıçapı: 0-46dp
- Logo: Nova dots, klavye arama, büyüteç, Google G, Monokrom
- Ek Eylemler: Hava durumu (AccuWeather), Play Store, Sesli ara - sürükle bırak sıralama

### 2. Klasörler
- Simge boyutu: %100-150
- Ana ekran boyutuna eşleştir
- Etiket aç/kapat
- Stil: Pencere / Klasik
- Gölge, Köşe Yarıçapı 46dp
- Klasör adını göster
- Kaydırma yönü: Yatay / Dikey
- Kılavuz: AUTO

### 3. Görünüm
- Simge stili (Adaptive icon tema ve şekil)
- Ana ekranı döndürmeye izin ver
- Uygulama animasyonu
- Açılır menü stili
- Bırakma hedefleri (Sil, Kaldır, Bilgi)
- Geri alma çubuğunu göster
- Animasyonları devre dışı bırak
- Bildirim çubuğu: Göster/Gizle, Şeffaf bildirim çubuğu, Şeffaf gezinti çubuğu, Koyu simgeler

### 4. Ana Ekran
- Düzen: Simge boyutu %125, Etiket, Kılavuz 7x5, Doldur (Küçük x Hiçbiri)
- Alt panel (dock) ayarları
- Arama çubuğu yeri
- Kaydırma: Duvar kağıdı kaydırma (Açık/Kapalı), Widget köşe yarıçapı 16dp, Geçiş efekti, Sonsuz kaydır, Sayfa göstergesi (Hiçbiri / noktalar)

### 5. Uygulama Menüsü
- Simge boyutu, Etiket
- Kılavuz 6x5
- Stil: Dikey / Yatay
- Geçiş animasyonu: Yukarı kaydır
- Arama çubuğu yeri: Alt
- Sekme çubuğu yerleşimi: Hiçbiri
- Sık kullanılan uygulamalar/kısayollar
- Akıllı Klasörler (otomatik kategorize)

## Nasıl Derlenir?
1. Bu projeyi GitHub'a pushla
2. Actions sekmesinde `Build APK` workflow'u otomatik çalışır
3. Artifact'ten APK'yı indir
4. Veya local: `./gradlew assembleDebug`

Lawnchair'ın orijinal kodunu bu iskeletin üzerine kopyalaman yeterli - `app.lawnchair` paketindeki kaynakları entegre et.

Lisans: Apache 2.0 (Lawnchair ile uyumlu)
